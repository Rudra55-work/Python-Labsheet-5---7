t=('banana','apple','cherry')
print(tuple(sorted(t)))