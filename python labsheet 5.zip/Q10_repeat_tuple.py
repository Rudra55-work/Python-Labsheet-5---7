t = (1,2)
print(t*3)