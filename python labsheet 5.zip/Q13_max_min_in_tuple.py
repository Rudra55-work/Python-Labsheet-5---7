t=(5,1,9,3)
print(max(t), min(t))