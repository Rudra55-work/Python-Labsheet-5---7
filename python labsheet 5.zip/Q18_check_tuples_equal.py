a=(1,2)
b=(1,2)
print(a==b)