t=(1,2,3)
print(sum(t))