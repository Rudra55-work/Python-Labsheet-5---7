l=[(1,2),(3,4)]
print(list(zip(*l)))