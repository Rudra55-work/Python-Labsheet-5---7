t = (1,2,3,4)
x=2
print(x in t)