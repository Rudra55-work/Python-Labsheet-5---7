t = (10,20,30,40)
print('First:', t[0], 'Second:', t[1])