t = (5,10,15,10)
print(t.index(10))