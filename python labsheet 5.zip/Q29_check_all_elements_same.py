t=(5,5,5)
print(len(set(t))==1)