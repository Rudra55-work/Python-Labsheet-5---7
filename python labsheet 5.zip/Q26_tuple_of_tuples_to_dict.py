t=((1,'a'),(2,'b'))
print(dict(t))