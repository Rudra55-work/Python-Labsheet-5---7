t=(1,2,2,3,3)
print([x for x in set(t) if t.count(x)>1])