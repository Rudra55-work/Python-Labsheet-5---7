lst=[1,2,3]
t=tuple(lst)
print(t)