t=(3,1,2)
print(tuple(sorted(t)))