t = (1, 'hello', 3.5, True)
print(t)