t=('apple','banana','pear')
print(max(t, key=len))