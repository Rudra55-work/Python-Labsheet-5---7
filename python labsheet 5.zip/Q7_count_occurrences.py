t = (1,2,2,3,2)
print(t.count(2))