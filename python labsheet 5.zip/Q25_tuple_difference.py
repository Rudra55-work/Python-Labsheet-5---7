a=(1,2,3)
b=(2,3,4)
print(tuple(set(a)-set(b)))