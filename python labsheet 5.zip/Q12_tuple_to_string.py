t=('H','i')
s=''.join(t)
print(s)