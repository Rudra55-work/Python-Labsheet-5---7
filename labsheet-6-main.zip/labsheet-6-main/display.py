s = {1, 2, 3, 4}
print('elements are:', s)