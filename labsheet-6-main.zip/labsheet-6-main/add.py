s = {1, 2, 3}
s.add(9)
print('set after adding an element:', s)