s = 'programming in python is easy then why not learn python'
words = s.split()
unique_words = set(words)
print('unique words:', unique_words)