s1 = {1, 2, 3, 4, 5}
s2 = {2, 3}
s1.difference_update(s2)
print('after difference:', s1)