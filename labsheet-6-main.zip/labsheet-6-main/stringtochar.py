s = 'python'
char_set = set(s)
print('set of characters:', char_set)