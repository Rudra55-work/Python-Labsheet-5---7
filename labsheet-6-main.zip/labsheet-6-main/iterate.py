s = {'cars', 'bikes', 'autos'}
for vehicle in s:
    print(vehicle)