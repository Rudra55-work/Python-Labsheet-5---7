s = [1, 2, 2, 3, 4, 4, 5]
distinct_set = set(s)
print('without duplicates:', distinct_set)