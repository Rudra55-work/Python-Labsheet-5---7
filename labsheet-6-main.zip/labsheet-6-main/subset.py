a = {1, 2}
b = {1, 2, 3, 4, 5}
print('is a subset of b:', a.issubset(b))