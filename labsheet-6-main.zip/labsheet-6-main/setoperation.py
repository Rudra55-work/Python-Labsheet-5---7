s1 = {1, 2, 3, 4, 5}
s2 = {4, 5, 6, 7, 8}
print('union:', s1.union(s2))
print('intersection:', s1.intersection(s2))
print('difference:', s1.difference(s2))
print('symmetric difference:', s1.symmetric_difference(s2))
print('set1:', s1)
print('set2:', s2)