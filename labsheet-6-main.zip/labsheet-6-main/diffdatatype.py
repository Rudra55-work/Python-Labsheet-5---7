s = {4, 'python', 4.56, True}
print('set with different datatypes:', s)