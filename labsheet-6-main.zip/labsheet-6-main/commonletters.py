s1 = 'python'
s2 = 'vscode'
common = set(s1).intersection(set(s2))
print('common letters:', common)