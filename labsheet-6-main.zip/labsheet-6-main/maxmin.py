s = {10, 20, 30, 40, 50}
print('maximum:', max(s))
print('minimum:', min(s))