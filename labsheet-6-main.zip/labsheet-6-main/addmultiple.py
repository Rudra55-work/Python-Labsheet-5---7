s = {1, 2, 3}
s.update([4, 5, 6])
print('set after adding multiple elements:', s)