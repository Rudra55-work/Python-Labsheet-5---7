s = {1, 1, 2, 2, 2, 3, 4, 4, 5}
distinct_count = len(s)
print('distinct element:', distinct_count)