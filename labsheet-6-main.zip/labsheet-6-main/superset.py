a = {1, 2, 3, 4, 5}
b = {1, 2}
print('is a superset of b:', a.issuperset(b))