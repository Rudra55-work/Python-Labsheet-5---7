s = {1, 2, 3, 4, 5}
s.clear()
print('set after clearing all elements:', s)