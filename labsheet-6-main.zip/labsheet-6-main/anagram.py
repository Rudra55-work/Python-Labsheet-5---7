s1 = 'act'
s2 = 'cat'
if set(s1) == set(s2):
    print(f'{s1} and {s2} are anagrams')
else:
    print(f'{s1} and {s2} are not anagrams')