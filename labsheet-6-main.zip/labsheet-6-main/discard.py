s = {1, 2, 3, 4, 5}
s.discard(10)
print('set after discarding an element:', s)