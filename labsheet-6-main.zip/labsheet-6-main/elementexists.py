s = {1, 2, 3, 4, 5}
print(2 in s)
print(7 in s)