import shutil
shutil.copy('students.csv', 'copy_students.csv')
print('CSV file copied.')