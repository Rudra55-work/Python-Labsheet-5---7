with open('sample.txt', 'r') as f:
    for line in f:
        print(line, end='')